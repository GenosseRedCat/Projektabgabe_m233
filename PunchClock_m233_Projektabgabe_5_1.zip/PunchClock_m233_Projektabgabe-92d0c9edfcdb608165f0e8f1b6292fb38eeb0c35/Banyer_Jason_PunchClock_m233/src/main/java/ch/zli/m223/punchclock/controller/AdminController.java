package ch.zli.m223.punchclock.controller;

/***
 * This class was created by Jason Banyer
 * Date: 05.11.2020
 *
 * Description of this class:
 * This class is an extension of the UserController and it serves to modify the same settings of the BenutzerController for the AdminController.
 *
 */
public class AdminController extends BenutzerController {


}
